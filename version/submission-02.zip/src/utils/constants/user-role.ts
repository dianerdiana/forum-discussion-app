export const USER_ROLES = {
  admin: 'ADMIN',
  sale: 'SALE',
};
