export const TOKEN_KEYS = {
  accessToken: 'accessToken',
};
