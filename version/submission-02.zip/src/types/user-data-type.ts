export type UserData = {
  userId: string;
  role: string;
  name: string;
};
