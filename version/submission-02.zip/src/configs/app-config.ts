export const appConfig = {
  logoUrl: '/logos/logo-brand.svg',
  // combination of logo and brand name
  logoBrandUrl: '/logos/logo-brand.svg',
  brandName: 'Leadova',
  localCurrency: 'id-ID',
  currency: 'IDR',
};
