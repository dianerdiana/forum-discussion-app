import type { User } from './user-type';

export type Leaderboard = {
  user: User;
  score: number;
};
