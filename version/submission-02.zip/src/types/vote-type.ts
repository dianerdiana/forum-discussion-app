export type Vote = {
  id: string;
  userId: string;
  threadId: string;
  voteType: number;
};
